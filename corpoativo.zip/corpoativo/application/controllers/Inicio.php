<?php
defined('BASEPATH') OR exit('No direct');
class Inicio extends CI_Controller{

	public function index(){
		  $this->load->view('template/header');
     $this->load->model('aula_model','aulas');
     $data['aulas'] =$this->aulas->getAula();
     $this->load->view('mostrarAula', $data);
 $this->load->view('template/footer');
	}
}