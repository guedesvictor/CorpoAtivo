<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Grupo extends CI_Controller {

	public function index(){
      
      $query = $this->db->query('SELECT first_name, email FROM customers');
   echo '<table class="table table-striped"><th>nome</th> <th> Email</th><tbody>';
foreach ($query->result() as $row)
{
    
     echo '<tr><td>' . $row->first_name . ' </td>';
         echo '<td>' . $row->email . '</td></tr>';
}
echo ' </tbody></table>';
echo 'Total Results: ' . $query->num_rows();
        }
 
	public function loreclean()
	{
		$this->load->view('loreclean');
	}
}
?>
 <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">