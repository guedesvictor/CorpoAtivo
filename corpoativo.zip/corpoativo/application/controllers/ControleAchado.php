<?php
session_start();
require_once "Achado.php";
	require_once "AchadoDAO.php";
	require_once "Contato.php";
	require_once "ContatoDAO.php";
	
	$acao = $_GET['acao'];
	if($acao == "cadastrarAchado"){		
	
	   
		$nome = $_POST["nome"];
		$tipo = $_POST["tipo"];
		$foto = $_FILES['foto'];
		    /*  ao receber a foto */
		$nomeFoto = '';

/*trabalhar com o arquivo e colocá-lo na pasta de fotos*/
if (getimagesize($foto['tmp_name'])) { //verifica se é imagem
	
	$extensao = pathinfo($foto['name'])['extension'];
	$novoCaminho = 'c:\xampp\htdocs\achados\assets\fotos\\' . md5($foto['tmp_name']) . '.' . $extensao;
	$nomeFoto = md5($foto['tmp_name']) . '.' . $extensao;
	//move_uploaded_file($foto['tmp_name'], $novoCaminho);
	
	$fn = $foto['tmp_name'];
	$size = getimagesize($fn);
	$ratio = $size[0]/$size[1]; // width/height
	if( $ratio > 1) {
		$width = 128;
		$height = 128/$ratio;
	}
	else {
		$width = 128*$ratio;
		$height = 128;
	}
	$src = imagecreatefromstring(file_get_contents($fn));
	$dst = imagecreatetruecolor($width,$height);
	imagecopyresampled($dst,$src,0,0,0,0,$width,$height,$size[0],$size[1]);
	imagedestroy($src);
	imagepng($dst, $novoCaminho); // adjust format as needed
	imagedestroy($dst);

}
		
		
		
		
		
		    /*  ao receber a foto */
	    $Idcontato = $_POST['id'];
		
		
		echo 'testando o session id'.$_POST['id'];
		$achado = new Achado();
		
		$achado->setNome($nome);
		
		$achado->setTipo($tipo);
			$achado->setFoto($nomeFoto);
			
		$achado->setIdcontato($Idcontato);
		
		
		$achadoDAO = new AchadoDAO();
		$achadoDAO->salvar($achado);		
		header('Location: painel.php');	
	}
	if($acao == "buscarAchados"){
		
		$achado = new Achado();
		$achado->setNome($_POST['nome']);
		$achado->setTipo($_POST['tipo']);
		$achadoDAO = new AchadoDAO();
		$listaAchados = $achadoDAO->buscar($achado);
		
		session_start();
		$_SESSION['listaAchados'] =  $listaAchados;
	
		header('Location: telaListarAchados.php');
	}
	if($acao == "buscarTodosAchados"){
		
		
		
		$achadoDAO = new AchadoDAO();
		$listaAchados = $achadoDAO->buscarTodos();
		
		session_start();
		$_SESSION['listaAchados'] =  $listaAchados;
	
		header('Location: telaListarTodosAchados.php');
	}
	if($acao == "excluir"){
		
		$achado = new Achado();
		$achado->setId($_GET['id']);
		
		$achadoDAO = new AchadoDAO();
		 $achadoDAO->Apagar($achado);
		
	
		header('Location: painel.php');
	}
	
	
	
	
	

?>