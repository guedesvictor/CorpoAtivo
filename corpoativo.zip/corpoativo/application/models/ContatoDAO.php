<?php

	
	require_once "Contato.php";
	require_once "Conexao.php";

	class ContatoDAO{
	    function buscar($contato){
			$conn = Conexao::getConexao();
						
			$stmt = $conn->prepare("select * from contatos where cod = :cod");	
			$stmt->bindParam(':cod', $contato->getCod());			
			$stmt->execute();
			
				$listaContatos = new ArrayObject();
			
			//pegar cada linha da resposta e gerar a lista de objtos Achado
			while($reg = $stmt->fetch(PDO::FETCH_OBJ)){
				
				//objeto Contato
				$contato = new Contato();				
				
				$contato->setNmContato($reg->nmContato);
				$contato->setFone($reg->fone);
				$contato->setEmail($reg->email);
				
				$listaContatos->append($contato);	
									
			}
			
			
			return $listaContatos;
		}
			
		function buscarContatoPeloId($contato){
			$conn = Conexao::getConexao();
						
			$stmt = $conn->prepare("select * from contatos where cod = :cod");	
			$stmt->bindParam(':cod', $contato->getCod());			
			$stmt->execute();	
			while($reg = $stmt->fetch(PDO::FETCH_OBJ)){
				
				//objeto Contato
				$contato = new Contato();				
				$contato->setCod($reg->cod);
				$contato->setNmContato($reg->nmContato);
				$contato->setFone($reg->fone);
				$contato->setEmail($reg->email);
				}
			
			
			return $contato;
		}
		function logar($contato){
			$conn = Conexao::getConexao();
						
			$stmt = $conn->prepare("select * from contatos where email = :email and senha = :senha");	
			$stmt->bindValue(':email', $contato->getEmail());
		    $stmt->bindValue(':senha', $contato->getSenha());			
			$stmt->execute();	
			while($reg = $stmt->fetch(PDO::FETCH_OBJ)){
				
				//objeto Contato
				$contato = new Contato();				
				$contato->setCod($reg->cod);
				$contato->setNmContato($reg->nmContato);
				$contato->setFone($reg->fone);
				$contato->setEmail($reg->email);
				$contato->setFoto($reg->foto);
					
									
			}
			
			
			return $contato;
		}
			
		
		function salvar($contato){		

			$conn = Conexao::getConexao();
			
				
			$stmt = $conn->prepare("INSERT INTO contatos ( nmContato, fone, email, senha) VALUES (:nmContato, :fone, :email, :senha)");	
			
			$stmt->bindParam(':nmContato', $contato->getNome());
			$stmt->bindParam(':fone', $contato->getFone());
			$stmt->bindParam(':email', $contato->getEmail());
			$stmt->bindParam(':senha', $contato->getSenha());
			
			$stmt->execute();			
		}
		
		
		
		
		
				
	}
	
	
?>