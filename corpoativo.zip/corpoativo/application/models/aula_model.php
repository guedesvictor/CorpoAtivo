<?php
class Aula_model extends CI_Model {
	function getAula(){
		$query = $this->db->get('aulas');
		return $query->result();
	}
	
}
