<?php
require_once "Contato.php";
	require_once "achado.php";
	require_once "ContatoDAO.php";
	require_once "Conexao.php";
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL ,
  `nome` varchar(255) NOT NULL ,
   `email` varchar(255) NOT NULL ,
  `cpf` varchar(16) ,
  `fone` varchar(16) ,
  `tipo` varchar(1) NOT NULL,
  `senha` varchar(32) NOT NULL,
  `status` varchar(32) ,
 
        `foto` varchar(32) 
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
	class AchadoDAO{
	
		function salvar($achado){		

			$conn = Conexao::getConexao();
			
			
			
			$stmt = $conn->prepare("INSERT INTO tb_achados (nome, tipo, foto, idContato) VALUES (:nome, :tipo, :foto, :idContato)");	
			
			$stmt->bindValue(':nome', $achado->getNome());
			$stmt->bindValue(':tipo', $achado->getTipo());
			$stmt->bindValue(':foto', $achado->getFoto());
			$stmt->bindValue(':idContato', $achado->getIdContato());
			
			$stmt->execute();			
		}
		
		function buscar($achado){
			
			$conn = Conexao::getConexao();
						
			$stmt = $conn->prepare("select * from tb_achados where nome = :nome and tipo = :tipo");	
			$stmt->bindParam(':nome', $achado->getNome());
			$stmt->bindParam(':tipo', $achado->getTipo());	
			$stmt->execute();
			
			
				$listaAchados = new ArrayObject();
			//pegar cada linha da resposta e gerar a lista de objtos Achado
			while($reg = $stmt->fetch(PDO::FETCH_OBJ)){
				
				//objeto Achado
				$achado = new Achado();				
				$achado->setId($reg->id);
				$achado->setNome($reg->nome);
				$achado->setTipo($reg->tipo);
				$achado->setFoto($reg->foto);
				$contato = new Contato();				
				
				$contato->setCod($reg->idContato);
				
				//ContatoDAO busca o Contato para setar no objeto Achado 				
				$contatoDAO = new ContatoDAO();
				$contato = $contatoDAO->buscarContatoPeloId($contato);				
				
				$achado->setIdContato($contato);
				$listaAchados->append($achado);					
			}
			
			return $listaAchados;
			
		}
		
		function buscarTodos(){
			
			$conn = Conexao::getConexao();
						
			$stmt = $conn->prepare("select * from tb_achados");	
			
			$stmt->execute();
			
			
				$listaAchados = new ArrayObject();
			//pegar cada linha da resposta e gerar a lista de objtos Achado
			while($reg = $stmt->fetch(PDO::FETCH_OBJ)){
				
				//objeto Achado
				$achado = new Achado();				
				$achado->setId($reg->id);
				$achado->setNome($reg->nome);
				$achado->setTipo($reg->tipo);
				$achado->setFoto($reg->foto);
				$listaAchados->append($achado);					
			}
			
			return $listaAchados;
			
		}
		function apagar($achado){
			
			$conn = Conexao::getConexao();
						
			$stmt = $conn->prepare("delete * from tb_achados where id = :id");	
			$stmt->bindValue(':id', $achado->getId());
			
			$stmt->execute();
		}	
	}
	
	
?>