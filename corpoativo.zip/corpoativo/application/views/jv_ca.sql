
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ca`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios` corpo ativo compreende todos os usuarios
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL ,
  `nome` varchar(255) NOT NULL ,
  `cpf` varchar(16) ,
  `fone` varchar(16) ,
  `nivel` varchar(1) NOT NULL,
  `senha` varchar(32) NOT NULL,
  `status` varchar(32) ,
 
        `foto` varchar(32) 
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Estrutura da tabela `exercicios`
--

CREATE TABLE `exercicios` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
    `foto` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Estrutura da tabela `treino`
--
CREATE TABLE `treinos` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL
       
    
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `lista` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
    `treino` int(11) ,
    `usuario` int(11) NOT NULL,
    `exercicio` int(11) NOT NULL,
	 `serie` varchar(11) NOT NULL,
	  `ciclo` varchar(11) NOT NULL,
	   `peso` float(11) NOT NULL,
	    `repeticao` varchar(11) NOT NULL
    
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `exercicios`
--
ALTER TABLE `exercicios`
  ADD PRIMARY KEY (`id`);
--
-- Indexes for table `usuarios`
--
ALTER TABLE `treinos`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `usuarios`
--
ALTER TABLE `lista`
  ADD PRIMARY KEY (`id`) USING BTREE;
  ADD KEY (`treino`);
 ADD  KEY (`usuario`);
 ADD  KEY (`exercicio`);
--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `exercicios`
--
ALTER TABLE `exercicios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `treinos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `exercicios`
--
ALTER TABLE `lista`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;






/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
