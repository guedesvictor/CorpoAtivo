<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>

<!DOCTYPE html>
<html lang="pt-br">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="ASVINICIUS">
<!-- Global site tag (gtag.js) - Google Ads: 865033734 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-865033734"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-865033734');
</script>
  <title>10%Desconto*Higienização de Qualidade*LoreClean</title>

  <!-- Bootstrap core CSS -->
  <link href="core/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <meta name="description" content="Dr.Tira Mancha - Limpeza, Higienização & Impermeabilização. A Dr.Tira Mancha é uma empresa especializada em Lavagem de sofá, colchões, e estofados em geral. Além da limpeza e higienização com alto padrão de qualidade, também fazemos impermeabilização, aumentando a durabilidade dos nossos serviços de limpeza. Para lavagem de bancos de automóveis, utilizamos produtos de primeira qualidade." />


  <!-- Custom styles for this template -->
  <link href="core/css/business-frontpage.css" rel="stylesheet">
<style type="text/css">

div.fixed{
  position: fixed;
  bottom: 0;
  width: 100%;
  padding: 5px;
  background-color:#32CD32; 
  text-align: center;}
 

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.hero-image {
  
  background-color: #cccccc;
  height: auto;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
}

.hero-text {
  text-align: center;
  position: absolute;
  top: 70%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
  -webkit-text-stroke-width: 1px;
-webkit-text-stroke-color: #000;
}
#forte{
font-size: 16px;
 -webkit-text-stroke-width: 1px;
-webkit-text-stroke-color: #dff;
}
#destaque{
  -webkit-text-stroke-width: 1px;
-webkit-text-stroke-color: #DF3A01; 
}
.texto-centralizado{
position: center;
}
.direita{
  margin-right: 15%;
 padding: 5px;

  text-align: right;
}
.centro{
padding: 5px;
margin-right: 50%;
  text-align: center;

}
#foot{
  padding:15px;  
    
}
#just{


  text-align: justify;
}
.float-banner {
    position: absolute;
    left: 5%;
    width: 200px; height: auto;
    margin-top: 100px; margin-left: -60px;
 
}
.img-banner{
  width: 200px;
     border-radius: 100px;
 
}
 
  .botao a{
  height:120px;
  width:120px;
  }
  .botao a:hover{
  margin-left:2px;
  margin-top:2px;
  

  border-radius:25%;
  
      }
        .box{
margin-top:10%;
position:float;
text-align:center;
border-radius:5px;
width:50%;
margin-left:25%;
background-color:red;
 background-image: url("/core/image/rosas.gif");

      }
        .simu{

width:100%;

      
      
      

      }
    </style>
</head>
  <body>
   <div id="float-banner" class="box float-banner">
  <div class="simu">
  <div class="botao">
   <a href="" rel="nofollow"class="btn btn-success">
    <img class="white" src="<? php echo base_url();?>core/image/sofa.svg" >
     <br> 
     <marquee>Proteja sua Familia, Veja aqui como barato é a Limpeza de seu Sofá</marquee>
     </img>  
   
    <a  href="975037956"> <span class="b_callnow">
                             <a href="tel:11975037956" rel="nofollow">
                                <a href="https://api.whatsapp.com/send?phone=5511975037956&text=Ola LoreClean, preciso de Serviços de Higienização de Estofados, meu nome é: " rel="nofollow"class=""></a> </a>

   </a> 
  
   <a href="" rel="nofollow"class="btn btn-info" title="imper"> 
    <img class="white" src="image/sofa.svg" >
     <br><marquee>Simule agora mesmo a Limpeza de seu Estofado</marquee>
     </img> 
   
     <a  href="975037956"> <span class="b_callnow">
                             <a href="tel:11975037956" rel="nofollow">
                                <a href="https://api.whatsapp.com/send?phone=5511975037956&text=Ola LoreClean, preciso de Serviços de Higienização de Estofados, meu nome é: " rel="nofollow"class=""></a> </a>
</a> 
   
  </div> 
   </div> </div>



<div id="float-banner" class="float-banner"><img class="img-banner" src="../core/image/banner1.gif" ></div>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">LoreClean   (11) 975037956</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="#">Rapidez
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Qualidade</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Segurança</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Acessivel</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

 
<!-- Header -->
  <header class="py-5 mb-5">

    <div class="container h-100   ">
        <div class="hero-image">
          <img src="bg-1.jpg" width="100%">
  <div class="hero-text">
    <h4 style="font-size:28px">Higienização de Estofados</h4>
    <h4>LoreClean</h4>
    <a  href="975037956"> <span class="b_callnow">
                             <a href="tel:11975037956" rel="nofollow">
                                <a href="https://api.whatsapp.com/send?phone=5511975037956&text=Ola LoreClean, preciso de Serviços de Higienização de Estofados, meu nome é: " rel="nofollow"class="btn btn-success"> <span class="">10% de desconto </span></a> </a>
  </div>
</div>
<br>
      <div class=" row h-100 align-items-center ">
        <div class="bg-info col-lg-12">
          
          <h4 class="display-4 text-white mt-5 mb-2">Qualidade, Rapidez e Segurança</h4>

          <p id="forte"  class="lead mb-5 text-white-50">O Cuidado que sua familia merece.
          </p>
          <p  id="forte">
            Atuamos na higienização de Sofa, Estofados Automotivos, Puffs, Colchões, Bebê Conforto, Tapetes.</p>
            <p id="destaque">Atuamos  também na lavagem de seu Carro.</p>
            <p id="forte"> Clique no botao e nos envie imagem do seu estafado para uma cotação agora mesmo</p>

                        
                          </span></a>

        </div>

                                                          </div>
      </div>
                              
  </header>
        <div class="centro">
         <a  href="975037956"> <span class="b_callnow">
                             <a href="tel:11975037956" rel="nofollow">
                                <a href="https://api.whatsapp.com/send?phone=5511975037956&text=Ola LoreClean, preciso de Serviços de Higienização de Estofados, meu nome é: " rel="nofollow"class="btn btn-success"> <span class="  glyphicon glyphicon-tint">Faça sua cotação agora com 10% de desconto </span></a> </a>
                                </div>
  <div class="direita">
<p> "Entrega o teu caminho ao Senhor, Confia nele, e tudo ele fará".</p>
<p>Salmo 37:5</p>
     <img src="core/biblia.jpg" width="50px"></img>


      
    </div>
  <!-- Page Content -->
  <div class="container">

    <div class="row">
      <div class="col-md-8 mb-5">
        <h2>Segurança</h2>
        <hr>
        <p id="just">Nossa parcela de segurança esta em dois princípios, o primeiro em preservar a integridade do produto a nós destinados à higienização, buscando aprimorar as técnicas necessárias para não danificar e dentro do possivel recuperar, e em segundo destinar ao cliente, funcionarios idoneos e profissionais.
</p>
       
        <a class="btn btn-danger btn-lg" href="#">Acaros</a>
         <a class="btn btn-danger btn-lg" href="#">Fungos</a>
          <a class="btn btn-danger btn-lg" href="#">Desgaste</a>
      </div>
      <div class="bg-info text-white col-md-4 mb-5">
        <h2>Entre em Contato</h2>
        <hr>
        <address>
          <strong>Nossos Endereços</strong>
          <br>Rua das ameixeiras,17 
          <br> SP
          <br>
        </address>
        <address>
          <abbr title="Zap">
         <strong>(11) 975037956</strong> 
          <br>
          <abbr title="Email">Email:</abbr>
          <a href="/cdn-cgi/l/email-protection#422b2c2d3427212e27232c707302252f232b2e6c212d2f"><span class="__cf_email__" data-cfemail="fd9493928b989e91989c93cfccbd9a909c9491d39e9290">[email&#160;protected]</span></a>
        </address>
      </div>
    </div>
    <!-- /.row -->

    <div class="row">
      <div class="col-md-4 mb-5">
        <div class="card h-100">
          <img class="card-img-top" src="core/image/caixa_antes.jpeg" alt="">
          <div class="card-body">
            <h4 class="card-title">Caixa de agua suja</h4>
            <p id="just" class="card-text">Deixar a caixa d’água suja só traz problemas para a saúde. As doenças mais comuns são gastroenterites, como diarréias e verminoses. Limpar o reservatório pelo menos a cada seis meses é essencial para garantir a eliminação de bactérias e de material orgânico..</p>
          </div>
          <div class="card-footer">
            <a href="#" class="btn btn-danger">Antes!</a>
          </div>
        </div>
      </div>
      <div class="col-md-4 mb-5">
        <div class="card h-100">
          <img class="card-img-top" src="core/image/caixa_depois.jpeg" alt="">
          <div class="card-body">
            <h4 class="card-title">Caixa de agua Limpa</h4>
            <p id="just"class="card-text">O professor de Engenharia Ambiental da Pontifícia Universidade Católica do Paraná (PUCPR), Arnaldo Carlos Müller, esclarece que a sujeira forma colônias de bactérias que se fixam nas paredes da caixa. Muitas delas são patogênicas. Com a contaminação pela eliminação do cloro, a sujeira pode entrar pela tubulação. “As partículas também resultam em odores e sabores desagradáveis na água”, observa. </p>
          </div>
          <div class="card-footer">
            <a href="#" class="btn btn-info">Depois</a>
          </div>
        </div>
      </div>
      <div class="col-md-4 mb-5">
        <div class="card h-100">
          <img class="card-img-top" src="core/image/carro_durante.jpeg"  alt="">
          <div class="card-body">
            <h4 class="card-title">limpeza de Carro</h4>
            <p id="just"class="card-text">Necessario limpar os estofados do carro, evitando doenças respiratorias..</p>
          </div>
          <div class="card-footer">
            <a  href="975037956"> <span class="b_callnow">
                             <a href="tel:11975037956" rel="nofollow">
                                <a href="https://api.whatsapp.com/send?phone=5511975037956&text=Ola LoreClean, preciso de Serviços de Higienização de Estofados, meu nome é: " rel="nofollow"class="btn btn-success"> Faça cotação agora c/ 10% de desconto </a> </a>
          </div>
        </div>
      </div>
    </div>
    <!-- /.row -->



 <!-- /.row2 -->

    <div class="row">
      <div class="col-md-4 mb-5">
        <div class="card h-100">
          <img class="card-img-top" src="core/image/sofa2_antes.jpeg" alt="">
          <div class="card-body">
            <h4 class="card-title">Sofa Sujo</h4>
            <p id="just" class="card-text">Limpeza de Sofa elimina ácaros e evita reações alérgicas dentro de casa.
Pessoas com rinite ou asma costumam sofrer mais com o problema.</p>
          </div>
          <div class="card-footer">
            <a href="#" class="btn btn-danger">Antes!</a>
          </div>
        </div>
      </div>
      <div class="col-md-4 mb-5">
        <div class="card h-100">
          <img class="card-img-top" src="core/image/sofa2_depois.jpeg" alt="">
          <div class="card-body">
            <h4 class="card-title">Sofa Limpo</h4>
            <p id="just"class="card-text">Limpeza de Estofados é importante e a higienização correta de colchōes, travesseiros, cobertores e também cortinas, objetos que podem acumular muitos ácaros. </p>
          </div>
          <div class="card-footer">
            <a href="#" class="btn btn-info">depois</a>
          </div>
        </div>
      </div>
      <div class="col-md-4 mb-5">
        <div class="card h-100">
          <img class="card-img-top" src="core/image/sofa_depois.jpeg" alt="">
          <div class="card-body">
            <h4 class="card-title">Sofa Limpo</h4>
            <p id="just"class="card-text">.</p>
          </div>
          <div class="card-footer">
            <a  href="975037956"> <span class="b_callnow">
                             <a href="tel:11975037956" rel="nofollow">
                                <a href="https://api.whatsapp.com/send?phone=5511975037956&text=Ola LoreClean, preciso de Serviços de Higienização de Estofados, meu nome é: " rel="nofollow"class="btn btn-success"> Faça cotação agora c/ 10% de desconto </a> </a>
          </div>
        </div>
      </div>
    </div>
    <!-- /.row2 -->


 <!-- /.row3 -->

    <div class="row">
      <div class="col-md-4 mb-5">
        <div class="card h-100">
          <img class="card-img-top" src="/core/tap1.jpeg" alt="">
          <div class="card-body">
            <h4 class="card-title">Tapete Manchado</h4>
            <p id="just" class="card-text">O tingimento de tapete persa usa corantes naturais, por isso é fragil, necessitando cuidado em relação a umidade e desgaste.</p>
          </div>
          <div class="card-footer">
            <a href="#" class="btn btn-danger">Antes!</a>
          </div>
        </div>
      </div>
      <div class="col-md-4 mb-5">
        <div class="card h-100">
          <img class="card-img-top" src="core/tap2.jpeg" alt="">
          <div class="card-body">
            <h4 class="card-title">Tapete tingido</h4>
            <p id="just"class="card-text">a tecnica de restauração é similar a ação do artesão ao fazer a peça, por isso é necessario conceito nas misturas de cores, o profissional torna-se um artesao ao mesmo que se profissionaliza </p>
          </div>
          <div class="card-footer">
            <a href="#" class="btn btn-info">Restaurando</a>
          </div>
        </div>
      </div>
      <div class="col-md-4 mb-5">
        <div class="card h-100">
          <img class="card-img-top" src="core/tap3.jpeg" alt="">
          <div class="card-body">
            <h4 class="card-title">Tribal Gasto</h4>
            <p id="just"class="card-text">Nos tribais as mandalas sao complexas e multicoloridas, carece de mais empenho, tornando o serviço mais moroso, contudo o exito deixa o profissional orgulhoso..</p>
          </div>
          <div class="card-footer">
            <a  href="975037956"> <span class="b_callnow">
                             <a href="tel:11975037956" rel="nofollow">
                                <a href="https://api.whatsapp.com/send?phone=5511975037956&text=Ola LoreClean, preciso de Serviços de Higienização de Estofados, meu nome é: " rel="nofollow"class="btn btn-success"> Faça cotação agora c/ 10% de desconto </a> </a>
          </div>
        </div>
      </div>
    </div>
    <!-- /.row3 -->



  </div>
  <!-- /.container -->
  <div>
      <h4>Localização</h4>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3653.524190635519!2d-47.34900788538061!3d-23.692967872349854!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94cf796bed0b5923%3A0xf1cac92793c78848!2sRua+Das+Ameixeiras%2C+Ibi%C3%BAna+-+SP%2C+18150-000!5e0!3m2!1spt-BR!2sbr!4v1555391679575!5m2!1spt-BR!2sbr" width="100%" height="auto" frameborder="1" style="border:1" allowfullscreen></iframe>
  </div>
  <br>
  <!-- Footer -->
  <footer class="py-5 bg-secondary">
    <div class="container">
        <p id="foot" class="m-0 text-center text-white">(11) 975037956</p> 
      <p id="foot" class="m-0 text-center text-white">Direitos reservados &copy; LoreClean 2019</p>
    </div>
    <!-- /.container -->
  </footer>

<div class="fixed btn-success">
            <a  href="975037956"> <span class="b_callnow">
                             <a href="tel:11975037956" rel="nofollow">
                                <a  href="https://api.whatsapp.com/send?phone=5511975037956&text=Ola LoreClean, preciso de Serviços de Higienização de Estofados, meu nome é: " rel="nofollow"class=""><i class="fa fa-whatsapp fa-2x"></i>  </span> <strong>Faça sua cotação agora com 10% de desconto</strong> </a> </a>
          </div>
  <!-- Bootstrap core JavaScript -->
  <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="vendor/jquery/jquery.min.js"></script>
  <script src="core/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript">

jQuery(document).ready(function() {
    $(window).scroll(function () {
        set = $(document).scrollTop()+"px";
        jQuery('#float-banner').animate(
            {top:set},
            {duration:1000, queue:false}
        );
    });
});
</script>
</body>

</html>