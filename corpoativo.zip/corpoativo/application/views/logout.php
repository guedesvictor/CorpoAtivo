<?php

session_start();
$_SESSION = array();
session_destroy();

Header('Location: http://localhost:8080/achados/login.php');

?>