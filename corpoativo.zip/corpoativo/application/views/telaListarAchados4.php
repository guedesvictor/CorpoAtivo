 <?php 
include "Achado.php";
		session_start();
		if (!isset($_SESSION['listaAchados'])) {
	header('Location: pesquisar.php?erro=2');
}
    $listaAchados = $_SESSION['listaAchados'];
		echo "<div class='centro'><img src='assets/img/logo.png'> ";
		if($listaAchados->count()!=0){
			echo "Achado o sequinte resultado:";
		}else{			
		header('Location: pesquisar.php?erro=1');	
		}
		echo "<table class='table table-striped' border='1px'>";		
echo "<thead class='thead-dark'>

      <tr>
        
        <th>nome/numero</th>
        <th>Tipo</th>
		<th>Foto</th>
      </tr>
    </thead>";
		foreach($listaAchados as $achado) {
			echo "<tr>";
			
			echo "<td>" . $achado->getNome() . "</td>";
			echo "<td>" . $achado->getTipo() . "</td>";
		
			echo "<td> <img src='assets/fotos/". $achado->getFoto(). ".png'></td>";
			echo "</tr>";
			
			}
			echo "</table>";	
			echo "<br>";
			echo "Contate o usuario abaixo .:";
			echo "<table class='table table-striped' border='1px'>";		
echo "<thead class='thead-dark'>

      	
      <tr class='table-success'>
        
        <th>Contato/local</th>
        <th>Fone</th>
		<th>Email</th>
      </tr>
    </thead>";
			echo "<tr>";        
			
			echo "<td>" . $achado->getIdContato()->getNmContato() . "</td>";
			echo "<td>" . $achado->getIdContato()->getFone() . "</td>";
			echo "<td>" . $achado->getIdContato()->getEmail() . "</td>";
		 	echo "</tr>";
		echo "</table>";
		unset($_SESSION['listaAchados']);
		
		?>