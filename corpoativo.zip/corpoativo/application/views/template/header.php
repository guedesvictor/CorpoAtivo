<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="academia Corpo Ativo">
	<meta name="author"      content="Elismar Olimpio dos Santos/oao Victor Guedes)">
	
	<title>CorpoAtivo</title>

	<link rel="shortcut icon" href="assets/images/gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="assets/css/bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="assets/css/main.css">

	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="assets/js/html5shiv.js"></script>
	<script src="assets/js/respond.min.js"></script>
	<style type="text/css">

.centrando{
	
text-align:center;
}


	</style>
	<![endif]-->
</head>

<body class="home centrando">
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom " >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<a class="navbar-brand" href="index.html"><img src="assets/images/logo.png" </a>
			</div>
			
		</div>

	<!-- /.navbar -->

	<!-- Header -->
	<header id="head">
		<div class="container">
			<div class="row">
				<h1 class="lead">O Melhor Lugar Para Descansar Sua Mente</h1>
				</div>
		</div>
	</header>
		</div> 
	<!-- /Header -->