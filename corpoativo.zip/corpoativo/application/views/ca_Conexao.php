<?php

	Class Conexao{
		
		
		private static $conn;
		
		static function getConexao(){
			
			$servername = "localhost:3307";
			$username = "root";
			$password = "";
			$dbname = "jc_ca";
			
			if(!self::$conn instanceof PDO){
				try{
					self::$conn = new PDO("mysql:host=".$servername.";dbname=".$dbname, $username, $password);
					// set the PDO error mode to exception
					
					self::$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					echo "Connection ok";
				}catch(PDOException $e){
					echo "Connection failed: " . $e->getMessage();
				}				
			}
			

			
			return self::$conn;
		}		
	}

?>