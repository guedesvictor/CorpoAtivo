<?php
defined('BASEPATH') OR exit('No direct script access allowed');
  echo '<table class="table table-striped"><th>Aula</th> <th> Exercicio</th><tbody>';
foreach ($aulas as $aula)
{
    
     echo '<tr><td>' . $aula->nome . ' </td>';
         echo '<td>' . $aula->exercicio . '</td></tr>';
}
echo ' </tbody></table>';

        
 ?>
  
<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  