<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'Inicio';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['servico'] = 'grupo/servico';
$route['loreclean'] = 'grupo/loreclean';
$route['tecwash'] = 'grupo/tecwash';